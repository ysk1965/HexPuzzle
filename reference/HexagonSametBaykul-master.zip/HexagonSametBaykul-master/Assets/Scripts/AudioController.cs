﻿using UnityEngine;
using System.Collections.Generic;

// --------------------------------------------------
// AudioController.cs
// --------------------------------------------------

public class AudioController : MonoBehaviour
{
    // --------------------------------------------------
    // PRIVATE VARIABLES
    // --------------------------------------------------

    private static AudioController staticInstance;
	private Dictionary<string, AudioSource> clips;

    // --------------------------------------------------
    // FUNDAMENTAL
    // --------------------------------------------------

    void Awake ()
    {
        staticInstance = GetComponent<AudioController>();

        _init_clip_dictionary();

        void _init_clip_dictionary()
        {
            clips = new Dictionary<string, AudioSource>();

            for (int i = 0; i < GetComponents<AudioSource>().Length; i++)
            {
                clips.Add(GetComponents<AudioSource>()[i].clip.name, GetComponents<AudioSource>()[i]);
            }
        }
    }

    // --------------------------------------------------
    // METHODS
    // --------------------------------------------------

    public static void PLAY(string clipName, float startTime = 0, ulong delay = 0)
    {
        List<AudioSource> _possible_clips = new List<AudioSource>();
        int _random_namber;

        foreach (string _clip_name in staticInstance.clips.Keys)
        {
            if (_clip_name.Contains(clipName))
            {
                _possible_clips.Add(staticInstance.clips[_clip_name]);
            }
        }

        _random_namber = (int)Random.Range(0, _possible_clips.Count);

        _possible_clips[_random_namber].time = startTime;
        _possible_clips[_random_namber].Play(delay);
    }
}
