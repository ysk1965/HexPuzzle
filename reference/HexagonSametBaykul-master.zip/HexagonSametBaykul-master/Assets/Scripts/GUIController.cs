﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

// --------------------------------------------------
// ENUMERATIONS
// --------------------------------------------------

public enum GUIState
{
    Game, GameOver
};

// --------------------------------------------------
// GUIController.cs
// --------------------------------------------------

public class GUIController : MonoBehaviour
{
    // --------------------------------------------------
    // EDITOR VARIABLES
    // --------------------------------------------------

    [Header("Editor Support")]
    public bool printStates = false;
    public bool printMessages = false;
    public bool deleteStorageAtStart;

    [Header("Game Panel")]
    public Camera mainCamera;
    public GameObject gamePanel; 
    public Text scoreText;
    public Text highScoreText;
    public Text possibleMatchText;
    public Image possibleMatchImage;
    public TextMeshProUGUI messageTMP;
    public Button restartButton;
    public Toggle toggleAudio;

    [Header("Game Over Panel")]
    public GameObject gameOverPanel;
    public Text gameOverScoreText;
    public Text gameOverHighScoreText;
    public Button gameOverRestartButton;

    // --------------------------------------------------
    // PRIVATE VARIABLES
    // --------------------------------------------------

    private static GUIController staticInstance;
    private static GUIState state;
    private static int score;
    private static int highScore;
    private static int possibleMatch;
    private static int totalMove;
    private static string message;
    private static bool isRestartButtonActive;
    private static bool isMessageWriting;
    private static bool isAudioActive;

    // --------------------------------------------------
    // FUNDAMENTAL
    // --------------------------------------------------

    private void Awake()
    {
        staticInstance = GetComponent<GUIController>();

        gamePanel.SetActive(true);
        messageTMP.gameObject.SetActive(false);
        gameOverPanel.SetActive(false);

        InitLocalStorage();
        InitAudioPreference();

        SCORE = 0;
        STATE = GUIState.Game;
    }

    // --------------------------------------------------
    // METHODS
    // --------------------------------------------------

    public static void INIT()
    {
        IS_RESTART_BUTTON_ACTIVE = true;

        staticInstance.mainCamera.GetComponent<AudioSource>().Play();

        STATE = GUIState.Game;

        staticInstance.gamePanel.SetActive(true);
        staticInstance.gameOverPanel.SetActive(false);
    }

    public static void GAME_OVER()
    {
        BoardController.TOUCHABLE = false;

        IS_RESTART_BUTTON_ACTIVE = true;

        staticInstance.mainCamera.GetComponent<AudioSource>().Stop();

        staticInstance.StartCoroutine(staticInstance.GameOver());
    }

    public void RESTART()
    {
        if (isRestartButtonActive && !isMessageWriting || STATE == GUIState.GameOver)
        {
            AudioController.PLAY("Click");

            INIT();

            SCORE = 0;
            IS_RESTART_BUTTON_ACTIVE = false;

            BoardCreator.RESTART_BOARD();
        }
    }

    public void TOGGLE_AUDIO(bool _checked)
    {
        AudioListener.pause = !_checked;

        AudioController.PLAY("Click");

        if (_checked)
        {
            PlayerPrefs.SetInt("audioPref", 1);
        }
        else
        {
            PlayerPrefs.SetInt("audioPref", 0);
        }
        
        PlayerPrefs.Save();
    }

    public void GO_TO_LINK()
    {
        Application.OpenURL("https://www.linkedin.com/in/sametbaykul/");
    }

    // Access Methods:

    public static int SCORE
    {
        set
        {
            score = value;

            staticInstance.scoreText.text = score.ToString();

            if (staticInstance.scoreText.gameObject.activeInHierarchy)
            {
                staticInstance.scoreText.gameObject.GetComponent<Animator>().Play("Change", 0, 0);
            }
        } 
        get
        {
            return score;
        }
    }

    public static int HIGH_SCORE
    {
        set
        {
            highScore = value;

            staticInstance.highScoreText.text = highScore.ToString();

            if (staticInstance.highScoreText.gameObject.activeInHierarchy)
            {
                staticInstance.highScoreText.gameObject.GetComponent<Animator>().Play("Change", 0, 0);
            }
        }
        get
        {
            return highScore;
        }
    }

    public static int POSSIBLE_MATCH
    {
        set
        {
            Image _possible_match_image = staticInstance.possibleMatchImage;
            Text _possible_match_text = staticInstance.possibleMatchText;
            int _chance = (value * 100) / totalMove;

            if (value > possibleMatch || _chance >= 45)
            {
                _possible_match_image.color = new Color(0.4f, 1, 0.4f, 1);
                _possible_match_image.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
                _possible_match_image.gameObject.GetComponent<Animator>().Play("Increase", 0, 0);
            }
            else if (value < possibleMatch - 5 || _chance <= 30)
            {
                _possible_match_image.color = new Color(1, 0.2f, 0.2f, 1);
                _possible_match_image.transform.rotation = Quaternion.Euler(new Vector3(0, 0, -180));
                _possible_match_image.gameObject.GetComponent<Animator>().Play("Decrease", 0, 0);
            }
            else
            {
                _possible_match_image.color = new Color(0, 0.6f, 1, 1);
                _possible_match_image.transform.rotation = Quaternion.Euler(new Vector3(0, 0, -90));
                _possible_match_image.gameObject.GetComponent<Animator>().Play("Stable", 0, 0);
            }

            possibleMatch = value;

            _possible_match_text.text = possibleMatch.ToString();
            _possible_match_text.gameObject.GetComponent<Animator>().Play("Change", 0, 0);
        }
        get
        {
            return possibleMatch;
        }
    }

    public static int TOTAL_MOVE
    {
        set
        {
            totalMove = value;
        }
    }

    public static string MESSAGE
    {
        set
        {
            message = value;

            if (isMessageWriting)
            {
                return;
            }

            if (staticInstance.printMessages)
            {
                print("MESSAGE: " + message);
            }

            staticInstance.messageTMP.text = message;
            staticInstance.messageTMP.gameObject.SetActive(true);
            staticInstance.StartCoroutine(staticInstance.FadeOutMessage());
        }
        get
        {
            return message;
        }
    }

    public static bool IS_RESTART_BUTTON_ACTIVE
    {
        set
        {
            isRestartButtonActive = value;
        }
    }

    public static GUIState STATE
    {
        set
        {
            state = value;

            if (staticInstance.printStates)
            {
                print("GUIController.STATE = " + state);
            }
        }
        get
        {
            return state;
        }
    }

    // --------------------------------------------------
    // FUNCTIONS
    // --------------------------------------------------

    private static void InitLocalStorage()
    {
        _set_highscore();
        _set_audio_preference();

        void _set_highscore()
        {
            if (PlayerPrefs.HasKey("highScore"))
            {
                if (staticInstance.deleteStorageAtStart)
                {
                    PlayerPrefs.SetInt("highScore", 0);
                }

                HIGH_SCORE = PlayerPrefs.GetInt("highScore", 0);
            }
        }

        void _set_audio_preference()
        {
            if(PlayerPrefs.HasKey("audioPref"))
            {
                if (staticInstance.deleteStorageAtStart)
                {
                    PlayerPrefs.SetInt("audioPref", 1);
                }

                isAudioActive = (PlayerPrefs.GetInt("audioPref", 1) > 0);
            }
            else
            {
                isAudioActive = true;

                PlayerPrefs.SetInt("audioPref", 1);
                PlayerPrefs.Save();
            }
        }
    }

    private static void InitAudioPreference()
    {
        AudioListener.pause = !isAudioActive;

        staticInstance.toggleAudio.isOn = isAudioActive;
    }

    // --------------------------------------------------
    // COROUTINES
    // --------------------------------------------------

    private IEnumerator GameOver()
    {
        STATE = GUIState.GameOver;

        yield return new WaitForSeconds(0.5f);

        Time.timeScale = BoardCreator.SLOW_MOTION_TIME_SCALE;

        _update_scores();
        _save_high_score();

        gamePanel.SetActive(false);
        gameOverPanel.SetActive(true);

        yield break;

        void _update_scores()
        {
            gameOverScoreText.text = score.ToString();
            gameOverHighScoreText.text = highScore.ToString();
        }

        void _save_high_score()
        {
            if (SCORE > HIGH_SCORE)
            {
                HIGH_SCORE = SCORE;

                PlayerPrefs.SetInt("highScore", HIGH_SCORE);
                PlayerPrefs.Save();
            }
        }
    }

    private IEnumerator FadeOutMessage()
    {
        isMessageWriting = true;

        yield return new WaitForSeconds(1);

        if (staticInstance.messageTMP.gameObject.activeInHierarchy)
        {
            staticInstance.messageTMP.gameObject.GetComponent<Animator>().Play("Delete", 0);
        }

        yield return new WaitForSeconds(0.5f);

        staticInstance.messageTMP.gameObject.SetActive(false);

        isMessageWriting = false;

        yield break;
    }
}
