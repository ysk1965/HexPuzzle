﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

// --------------------------------------------------
// ENUMERATIONS
// --------------------------------------------------

public enum SliceColliderDirection { up, upRight, downRight, down, downLeft, upLeft };

// --------------------------------------------------
// EVENTS
// --------------------------------------------------

[System.Serializable]

public class SliceTouchEvent : UnityEvent<SliceColliderDirection>
{
    // ...
}

// --------------------------------------------------
// ColliderSliceController.cs
// --------------------------------------------------

public class ColliderSliceController : MonoBehaviour
{
    // --------------------------------------------------
    // EDITOR VARIABLES
    // --------------------------------------------------

    public SliceColliderDirection sliceColliderDirection = SliceColliderDirection.up;

    // --------------------------------------------------
    // PRIVATE VARIABLES
    // --------------------------------------------------

    private SliceTouchEvent sliceTriggerEvent;

    // --------------------------------------------------
    // FUNDAMENTAL
    // --------------------------------------------------

    void Awake()
    {
        sliceTriggerEvent = new SliceTouchEvent();
    }

    void OnMouseDown()
    {
        sliceTriggerEvent.Invoke(sliceColliderDirection);
    }

    // --------------------------------------------------
    // METHODS
    // --------------------------------------------------

    public SliceTouchEvent SLICE_TRIGGER_EVENT
    {
        get
        {
            return sliceTriggerEvent;
        }
    }
}
