﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// --------------------------------------------------
// ENUMERATIONS
// --------------------------------------------------

public enum Direction { UpRight, Right, DownRight, DownLeft, Left, UpLeft, Up, Down, Center };

public enum BoardCreatorState 
{
    Idle, Creating, CreatingEffect, Deleting,
    CreatingEffectComplete
};

// --------------------------------------------------
// BoardCreator.cs
// --------------------------------------------------

public class BoardCreator : MonoBehaviour
{
    // --------------------------------------------------
    // EDITOR VARIABLES
    // --------------------------------------------------

    [Header("Tile Specifications")]
    public TileController tile;
    public List<Color> tileColors = new List<Color>();

    [Header("Tile Placement")]
    public bool firstRowIndentation = true;
    public int boardTileCountsX = 8;
    public int boardTileCountsY = 9;
    public Vector2 tileOffsets;
    public float sizeModifier = 0.28f;

    [Header("Game Fluency")]
    [Range(0.1f, 1f)]
    public float nominalTimeScale = 1;
    [Range(0.1f, 1f)]
    public float slowMotionTimeScale = 0.5f;
    [Range(-1080f, 1080f)]
    public float rotationSpeed = 720;
    [Range(0f, 10f)]
    public float fallingSpeed = 5;
    [Range(0.1f, 5f)]
    public float openingSpeed = 1;
    [Range(0.01f, 1f)]
    public float progressDelay = 0.05f;
    [Range(0.01f, 2f)]
    public float openingEffectDelay = 0.8f;
    [Range(0.01f, 1f)]
    public float bombBlowDelay = 0.25f;
    [Range(0.02f, 2f)]
    public float tileCrushDelay = 1;

    [Header("Editor Support")]
    public bool printStates = false;
    public bool printTileGridAtStart = false;

    // --------------------------------------------------
    // PRIVATE VARIABLES
    // --------------------------------------------------

    private static BoardCreator staticInstance;
    private static TileController[,] tileGrid;
    private static BoardCreatorState state;
    private static Vector3[,] positionGrid;
    private static Vector2 tileCenterDistance;
    private static Vector3 startingPosition;

    // --------------------------------------------------
    // FUNDAMENTAL
    // --------------------------------------------------

    void Start()
    {
        Init();

        CREATE_BOARD();
    }

    // --------------------------------------------------
    // METHODS
    // --------------------------------------------------

    // Board Methods:

    public static void CREATE_BOARD()
    {
        if (STATE != BoardCreatorState.Idle)
        {
            return;
        }

        Time.timeScale = staticInstance.nominalTimeScale;

        GUIController.INIT();

        staticInstance.StartCoroutine(staticInstance.CreateBoard());
    }

    public static void DELETE_BOARD()
    {
        if (STATE != BoardCreatorState.Idle)
        {
            return;
        }

        BoardController.TOUCHABLE = false;

        staticInstance.StartCoroutine(staticInstance.DeleteBoard());
    }

    public static void RESTART_BOARD()
    {
        if (STATE != BoardCreatorState.Idle)
        {
            return;
        }

        Time.timeScale = staticInstance.nominalTimeScale;

        GUIController.MESSAGE = "Mixing";

        staticInstance.StartCoroutine(staticInstance.RestartBoard());
    }

    public static TileController CREATE_TILE(int gridX, int gridY)
    {
        GameObject _tile_game_object = Instantiate(BoardCreator.staticInstance.tile.gameObject);
        TileController _tile_controller = _tile_game_object.GetComponent<TileController>();
        Vector3 _tile_position = positionGrid[gridX, gridY];

        _tile_controller.START(BoardCreator.staticInstance.transform, _tile_position, new Vector2(gridX, gridY));
        _tile_controller.CLOUD_EFFECT();

        BoardCreator.staticInstance.SetTileColor(_tile_controller, gridX);
        BoardCreator.staticInstance.SetTileScale(_tile_controller);

        tileGrid[gridX, gridY] = _tile_controller;

        return _tile_controller;
    }

    public static void DELETE_TILE(Vector2 tileGridPosition)
    {
        TileController _tile_will_be_deleted = tileGrid[(int)tileGridPosition.x, (int)tileGridPosition.y];

        tileGrid[(int)tileGridPosition.x, (int)tileGridPosition.y] = null;

        _tile_will_be_deleted.CRUSH_EFFECT();

        staticInstance.StartCoroutine(staticInstance.DeleteTile(_tile_will_be_deleted.gameObject, staticInstance.tileCrushDelay));  
    }


    // Grid Reference Methods:

    public static bool CHECK_ADJACENT_TILE(TileController tileInCenter, Direction adjacentDirection)
    {
        if (tileInCenter == null)
        {
            return false;
        }

        Vector2 _adjacent_tile_grid_pos;
        int _pos_x = (int)tileInCenter.GRID_POSITION.x;
        int _pos_y = (int)tileInCenter.GRID_POSITION.y;
        int _limit_pos_x = tileGrid.GetLength(0) - 1;
        int _limit_pos_y = tileGrid.GetLength(1) - 1;
        bool is_in_even_row = IS_ROW_INDENTED(_pos_y);
        bool _result;

        if (is_in_even_row)
        {
            switch (adjacentDirection)
            {
                case Direction.UpRight:
                    _result = (_pos_x < _limit_pos_x) && (_pos_y < _limit_pos_y);
                    break;
                case Direction.Right:
                    _result = (_pos_x < _limit_pos_x);
                    break;
                case Direction.DownRight:
                    _result = (_pos_x < _limit_pos_x) && (_pos_y > 0);
                    break;
                case Direction.DownLeft:
                    _result = (_pos_y > 0);
                    break;
                case Direction.Left:
                    _result = (_pos_x > 0);
                    break;
                case Direction.UpLeft:
                    _result = (_pos_y < _limit_pos_y);
                    break;
                case Direction.Up:
                    _result = (_pos_y < _limit_pos_y);
                    break;
                case Direction.Down:
                    _result = (_pos_y > 0);
                    break;
                default:
                    return false;
            }
        }
        else
        {
            switch (adjacentDirection)
            {
                case Direction.UpRight:
                    _result = (_pos_y < _limit_pos_y);
                    break;
                case Direction.Right:
                    _result = (_pos_x < _limit_pos_x);
                    break;
                case Direction.DownRight:
                    _result = (_pos_y > 0);
                    break;
                case Direction.DownLeft:
                    _result = (_pos_x > 0) && (_pos_y > 0);
                    break;
                case Direction.Left:
                    _result = (_pos_x > 0);
                    break;
                case Direction.UpLeft:
                    _result = (_pos_x > 0) && (_pos_y < _limit_pos_y);
                    break;
                case Direction.Up:
                    _result = (_pos_y < _limit_pos_y);
                    break;
                case Direction.Down:
                    _result = (_pos_y > 0);
                    break;
                default:
                    return false;
            }
        }

        if (_result)
        {
            _adjacent_tile_grid_pos = GET_ADJACENT_TILE_GRID_POSITION(tileInCenter, adjacentDirection);

            _result = (tileGrid[(int)_adjacent_tile_grid_pos.x, (int)_adjacent_tile_grid_pos.y] != null);
        }

        return _result;
    }

    public static TileController GET_ADJACENT_TILE(TileController tileInCenter, Direction adjacentDirection)
    {
        if (CHECK_ADJACENT_TILE(tileInCenter, adjacentDirection))
        {
            Vector2 _adjacent_tile_pos = GET_ADJACENT_TILE_GRID_POSITION(tileInCenter, adjacentDirection);

            return tileGrid[(int)_adjacent_tile_pos.x, (int)_adjacent_tile_pos.y];
        }
        else
        {
            return null;
        }
    }

    public static TileController[] GET_ADJACENT_TILES(TileController tileInCenter, bool centerTileIsIncluded, params Direction[] adjacentDirections)
    {
        TileController[] _adjacent_tiles_found;
        int _start_index;

        if (centerTileIsIncluded)
        {
            _adjacent_tiles_found = new TileController[adjacentDirections.Length + 1];
            _adjacent_tiles_found[0] = tileInCenter;
            _start_index = 1;
        }
        else
        {
            _adjacent_tiles_found = new TileController[adjacentDirections.Length];
            _start_index = 0;
        }

        for (int i = 0; i < adjacentDirections.Length; i++)
        {
            _adjacent_tiles_found[_start_index + i] = GET_ADJACENT_TILE(tileInCenter, adjacentDirections[i]);
        }

        return _adjacent_tiles_found;
    }

    public static Vector2 GET_ADJACENT_TILE_GRID_POSITION(TileController tileInCenter, Direction adjacentDirection)
    {
        Vector2 _adjacent_tile_position = tileInCenter.GRID_POSITION;
        bool is_in_even_row = IS_ROW_INDENTED((int)tileInCenter.GRID_POSITION.y);

        if (is_in_even_row)
        {
            switch (adjacentDirection)
            {
                case Direction.UpRight:
                    _adjacent_tile_position.x++;
                    _adjacent_tile_position.y++;
                    break;
                case Direction.Right:
                    _adjacent_tile_position.x++;
                    break;
                case Direction.DownRight:
                    _adjacent_tile_position.x++;
                    _adjacent_tile_position.y--;
                    break;
                case Direction.DownLeft:
                    _adjacent_tile_position.y--;
                    break;
                case Direction.Left:
                    _adjacent_tile_position.x--;
                    break;
                case Direction.UpLeft:
                    _adjacent_tile_position.y++;
                    break;
                case Direction.Up:
                    _adjacent_tile_position.y++;
                    break;
                case Direction.Down:
                    _adjacent_tile_position.y--;
                    break;
            }
        }
        else
        {
            switch (adjacentDirection)
            {
                case Direction.UpRight:
                    _adjacent_tile_position.y++;
                    break;
                case Direction.Right:
                    _adjacent_tile_position.x++;
                    break;
                case Direction.DownRight:
                    _adjacent_tile_position.y--;
                    break;
                case Direction.DownLeft:
                    _adjacent_tile_position.x--;
                    _adjacent_tile_position.y--;
                    break;
                case Direction.Left:
                    _adjacent_tile_position.x--;
                    break;
                case Direction.UpLeft:
                    _adjacent_tile_position.x--;
                    _adjacent_tile_position.y++;
                    break;
                case Direction.Up:
                    _adjacent_tile_position.y++;
                    break;
                case Direction.Down:
                    _adjacent_tile_position.y--;
                    break;
            }
        }

        return _adjacent_tile_position;
    }

    public static Vector3 GET_ADJACENT_TILE_WORLD_POSITION(TileController tileInCenter, Direction adjacentDirection)
    {
        Vector2 _grid_pos = GET_ADJACENT_TILE_GRID_POSITION(tileInCenter, adjacentDirection);

        return positionGrid[(int)_grid_pos.x, (int)_grid_pos.y];
    }

    public static bool IS_ROW_INDENTED(int Y)
    {
        if (staticInstance.firstRowIndentation)
        {
            return !(Y % 2 == 0);
        }
        else
        {
            return (Y % 2 == 0);
        }
    }

    public static List<Triangle> FIND_TRIANGLES()
    {
        List<Triangle> _triangle_list = new List<Triangle>();
        int _triangle_no = 0;

        for (int x = 0; x < BoardCreator.staticInstance.boardTileCountsX; x++)
        {
            for (int y = 0; y < BoardCreator.staticInstance.boardTileCountsY - 1; y++)
            {
                TileController[] _new_triangle_elements;

                _new_triangle_elements = GET_ADJACENT_TILES(tileGrid[x, y], true, Direction.Left, Direction.UpLeft);

                if (_is_a_triangle(_new_triangle_elements))
                {
                    Triangle _new_triangle = new Triangle(_triangle_no, false, _new_triangle_elements);

                    _triangle_list.Add(_new_triangle);

                    _triangle_no++;
                }

                _new_triangle_elements = GET_ADJACENT_TILES(tileGrid[x, y], true, Direction.UpLeft, Direction.UpRight);

                if (_is_a_triangle(_new_triangle_elements))
                {
                    Triangle _new_triangle = new Triangle(_triangle_no, true, _new_triangle_elements);

                    _triangle_list.Add(_new_triangle);

                    _triangle_no++;
                }
            }
        }

        return _triangle_list;

        bool _is_a_triangle(TileController[] _triangle)
        {
            for (int i = 0; i < _triangle.Length; i++)
            {
                if (_triangle[i] == null)
                {
                    return false;
                }
            }

            return true;
        }
    }

    // Editor Supports:

    public static void PRINT_TILE_GRID(TileController[,] grid = null)
    {
        print(" -> TILE_GRID():");

        if (grid == null)
        {
            grid = tileGrid;
        }

        for (int x = 0; x < grid.GetLength(0); x++)
        {
            for (int y = 0; y < grid.GetLength(1); y++)
            {
                bool _tile_exist = (grid[x, y] != null);
                string _txt = "GRID[" + x + ", " + y + "] -> EXIST: " + _tile_exist;

                if (_tile_exist)
                {
                    _txt += " | GRID_POS: " + grid[x, y].GRID_POSITION;
                    _txt += " | EVEN_ROW: " + BoardCreator.IS_ROW_INDENTED(y);
                    _txt += " | COLOR: " + grid[x, y].COLOR;
                }

                print(_txt);
            }
        }

        print("---END---");
    }

    // Access Methods:

    public static TileController[,] TILE_GRID
    {
        get
        {
            return tileGrid;
        }
    }

    public static Vector3[,] POSITION_GRID
    {
        get
        {
            return positionGrid;
        }
    }

    public static float ROTATION_SPEED
    {
        get
        {
            return staticInstance.rotationSpeed;
        }
    }

    public static float FALLING_SPEED
    {
        get
        {
            return staticInstance.fallingSpeed;
        }
    }

    public static float PROGRESS_DELAY
    {
        get
        {
            return staticInstance.progressDelay;
        }
    }

    public static float BOMB_BLOW_DELAY  
    {
        get
        {
            return staticInstance.bombBlowDelay;
        }
    }

    public static float SLOW_MOTION_TIME_SCALE
    {
        get
        {
            return staticInstance.slowMotionTimeScale;
        }
    }

    public static BoardCreatorState STATE
    {
        set
        {
            state = value;

            if (staticInstance.printStates)
            {
                print("BoardCreator.STATE = " + state);
            }
        }
        get
        {
            return state;
        }
    }

    // --------------------------------------------------
    // FUNCTIONS
    // --------------------------------------------------

    private void Init()
    {
        staticInstance = GetComponent<BoardCreator>();
        tileGrid = new TileController[boardTileCountsX, boardTileCountsY];
        positionGrid = new Vector3[boardTileCountsX, boardTileCountsY];
        tileCenterDistance = tile.BOUND_SIZE * sizeModifier;
        startingPosition = transform.position;

        STATE = BoardCreatorState.Idle;
    }

    private  void SetTileColor(TileController _tile_controller, int _x)
    {
        List<Color> _possible_colors = new List<Color>();
        Color _tile_color;

        _possible_colors.AddRange(tileColors);

        if (_x > 0)
        {
            _extract_matches();
        }

        _tile_color = _possible_colors[Random.Range(0, _possible_colors.Count)];
        _tile_controller.COLOR = _tile_color;

        void _extract_matches()
        {
            _check_tile_colors(GET_ADJACENT_TILES(_tile_controller, false, Direction.UpRight, Direction.Right));
            _check_tile_colors(GET_ADJACENT_TILES(_tile_controller, false, Direction.Right, Direction.DownRight));
            _check_tile_colors(GET_ADJACENT_TILES(_tile_controller, false, Direction.DownRight, Direction.DownLeft));
            _check_tile_colors(GET_ADJACENT_TILES(_tile_controller, false, Direction.DownLeft, Direction.Left));
            _check_tile_colors(GET_ADJACENT_TILES(_tile_controller, false, Direction.Left, Direction.UpLeft));
            _check_tile_colors(GET_ADJACENT_TILES(_tile_controller, false, Direction.UpLeft, Direction.UpRight));
        }

        void _check_tile_colors(TileController[] _adjacent_tile_colors)
        {
            if (_adjacent_tile_colors[0] != null && _adjacent_tile_colors[1] != null)
            {
                if (_adjacent_tile_colors[0].COLOR == _adjacent_tile_colors[1].COLOR)
                {
                    _possible_colors.Remove(_adjacent_tile_colors[0].COLOR);
                }
            }
        }
    }

    private void SetTileScale(TileController _tile_controller)
    {
        _tile_controller.SET_SCALE(new Vector2(sizeModifier, sizeModifier));
    }

    // --------------------------------------------------
    // COROUTINES
    // --------------------------------------------------

    private IEnumerator CreateBoard()
    {
        STATE = BoardCreatorState.Creating;

        _create_tiles();
        _update_grid_positions();

        yield return new WaitForSeconds(progressDelay);

        StartCoroutine(ProcessCreationEffect());

        yield return new WaitUntil(() => STATE == BoardCreatorState.CreatingEffectComplete);

        BoardController.INIT();

        STATE = BoardCreatorState.Idle;

        _complete_creating_board();

        yield break;

        void _create_tiles()
        {
            for (int x = 0; x < boardTileCountsX; x++)
            {
                for (int y = 0; y < boardTileCountsY; y++)
                {
                    _create_tile(x, y);
                }
            }
        }

        void _update_grid_positions()
        {
            for (int x = 0; x < boardTileCountsX; x++)
            {
                for (int y = 0; y < boardTileCountsY; y++)
                {
                    positionGrid[x, y] = tileGrid[x, y].WORLD_POSITISON;
                }
            }
        }

        void _complete_creating_board()
        {
            if (BoardController.FIND_POSSIBLE_MATCH_MOVES().Count == 0)
            {
                RESTART_BOARD();
            }
            else
            {
                if (printTileGridAtStart)
                {
                    PRINT_TILE_GRID();
                }

                GUIController.IS_RESTART_BUTTON_ACTIVE = true;
            }
        }

        void _create_tile(int _x, int _y)
        {
            GameObject _tile_game_object = Instantiate(tile.gameObject);
            TileController _tile_controller = _tile_game_object.GetComponent<TileController>();

            _set_tile_position(_tile_controller, _x, _y);

            SetTileColor(_tile_controller, _x);
            SetTileScale(_tile_controller);

            tileGrid[_x, _y] = _tile_controller;
        }

        void _set_tile_position(TileController _tile_controller, int _x, int _y)
        {
            Vector3 _tile_position = new Vector3(startingPosition.x, startingPosition.y, -1);
            Quaternion _tile_rotation = tile.transform.rotation;

            if (_x == 0)
            {
                if (IS_ROW_INDENTED(_y))
                {
                    _tile_position.x = startingPosition.x + (tileCenterDistance.x + tileOffsets.x) * 0.5f;
                }
                else
                {
                    _tile_position.x = startingPosition.x;
                }
            }
            else
            {
                if (IS_ROW_INDENTED(_y))
                {
                    _tile_position.x = startingPosition.x + (tileCenterDistance.x + tileOffsets.x) * 0.5f + (tileCenterDistance.x + tileOffsets.x) * _x;
                }
                else
                {
                    _tile_position.x = startingPosition.x + (tileCenterDistance.x + tileOffsets.x) * _x;
                }
            }

            if (_y == 0)
            {
                _tile_position.y = startingPosition.y;
            }
            else
            {
                _tile_position.y = tileGrid[0, _y - 1].transform.position.y + (tileCenterDistance.y * 0.75f) + tileOffsets.y;
            }

            _tile_controller.START(transform, _tile_position, new Vector2(_x, _y));
        }
    }

    private IEnumerator DeleteBoard()
    {
        STATE = BoardCreatorState.Deleting;

        // Deletes board tiles from the bottom row though the top

        for (int y = 0; y < boardTileCountsY; y++)
        {
            for (int x = 0; x < boardTileCountsX; x++)
            {
                TileController _tile_will_be_deleted = tileGrid[x, y];

                tileGrid[x, y] = null;

                _tile_will_be_deleted.CLOUD_EFFECT();

                staticInstance.StartCoroutine(staticInstance.DeleteTile(_tile_will_be_deleted.gameObject, 0.2f / openingSpeed));
            }

            yield return new WaitForSeconds(openingSpeed * progressDelay * 5 / boardTileCountsY);
        }

        STATE = BoardCreatorState.Idle;

        yield break;
    }

    private IEnumerator RestartBoard()
    {
        DELETE_BOARD();

        yield return new WaitUntil (() => state == BoardCreatorState.Idle);
        yield return new WaitForSeconds(0.2f / openingSpeed);

        CREATE_BOARD();

        yield break;
    }

    private IEnumerator ProcessCreationEffect()
    {
        int _diagonal_length = boardTileCountsX + boardTileCountsY - 1;
        TileController[][] _tiles_in_diagonal = _find_diagonal_matrix_of_tile_grid();

        STATE = BoardCreatorState.CreatingEffect;

        yield return new WaitForSeconds(openingEffectDelay);

        AudioController.PLAY("Opening", 1.6f);

        // Apply creation effect to the diagonal matrix of the board

        for (int i = 0; i < _tiles_in_diagonal.Length; i++)
        {
            for (int j = 0; j < _tiles_in_diagonal[i].Length; j++)
            {
                _tiles_in_diagonal[i][j].CLOUD_EFFECT();
            }

            yield return new WaitForSeconds(openingSpeed * progressDelay * 5 / _diagonal_length);
        }

        STATE = BoardCreatorState.CreatingEffectComplete;

        yield break;

        TileController[][] _find_diagonal_matrix_of_tile_grid()
        {
            TileController[][] _tiles_in_diagonal_found = new TileController[_diagonal_length][];

            for (int i = 0; i < _diagonal_length; i++)
            {
                int _start_column = Mathf.Max(0, i - boardTileCountsX + 1);
                int _diagonal_line_length = Mathf.Min(i + 1, Mathf.Min((boardTileCountsY - _start_column), boardTileCountsX));

                _tiles_in_diagonal_found[i] = new TileController[_diagonal_line_length];

                for (int j = 0; j < _diagonal_line_length; j ++)
                {
                    _tiles_in_diagonal_found[i][j] = tileGrid[Mathf.Min(boardTileCountsX, i + 1) - j - 1, _start_column + j];
                }
            }

            return _tiles_in_diagonal_found;
        }
    }

    private IEnumerator DeleteTile(GameObject _tile, float _delay)
    {
        yield return new WaitForSeconds(_delay);

        _tile.SetActive(false);

        yield return new WaitForSeconds(_delay);

        GameObject.Destroy(_tile);

        yield break;
    }
}

// --------------------------------------------------
// Triangle.cs
// --------------------------------------------------

public class Triangle
{
    public int triangleNo;
    public bool isVshape;
    public bool hasBinaryColor;
    public Color binaryColorIfHas;
    public TileController centerTile;
    public TileController leftTile;
    public TileController rightTile;

    private Color irrelevantColor;

    public Triangle(int no, bool isVShape, TileController[] elements)
    {
        triangleNo = no;
        isVshape = isVShape;
        centerTile = elements[0];
        leftTile = elements[1];
        rightTile = elements[2];

        irrelevantColor = new Color(0, 0, 0, 0);
        binaryColorIfHas = GetBinaryColorIfHas();
        hasBinaryColor = CheckBinaryColor();
    }

    private Color GetBinaryColorIfHas()
    {
        if (centerTile.COLOR == leftTile.COLOR)
        {
            return centerTile.COLOR;
        }

        if (leftTile.COLOR == rightTile.COLOR)
        {
            return leftTile.COLOR;
        }

        if (centerTile.COLOR == rightTile.COLOR)
        {
            return rightTile.COLOR;
        }

        return irrelevantColor;
    }

    private bool CheckBinaryColor()
    {
        return !(binaryColorIfHas.Equals(irrelevantColor));
    }
}
