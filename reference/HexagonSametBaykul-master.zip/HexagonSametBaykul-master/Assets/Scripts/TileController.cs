﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// --------------------------------------------------
// TileController.cs
// --------------------------------------------------

public class TileController : MonoBehaviour
{
    // --------------------------------------------------
    // EDITOR VARIABLES
    // --------------------------------------------------

    [Header("Objects")]
    public GameObject tileSpriteContainer;
    public GameObject bombContainer;
    public Text bombCountdownText;

    [Header("Sprites")]
    public Sprite regularTileSprite;
    public Sprite crackedTileSprite1;
    public Sprite crackedTileSprite2;

    [Header("Effects")]
    public GameObject spawnParticleEffect;
    public GameObject crushParticleEffect;
    public GameObject explosionParticleEffect;

    [Header("Colliders")]
    public ColliderSliceController sliceColliderUp;
    public ColliderSliceController sliceColliderUpRight;
    public ColliderSliceController sliceColliderDownRight;
    public ColliderSliceController sliceColliderDown;
    public ColliderSliceController sliceColliderDownLeft;
    public ColliderSliceController sliceColliderUpLeft;

    // --------------------------------------------------
    // PRIVATE VARIABLES
    // --------------------------------------------------

    private enum TileSprite { regular, crack_1, crack_2 };
    private ColliderSliceController[] colliderSliceControllers;
    private GameObject[] particleObjects;
    private bool isAlive;
    private Vector2 boundSize;
    private Vector2 gridPosition;
    private Vector3 worldPosition;
    private Color color;

    // Bomb:

    private bool isBombPlanted;
    private int bombCountdown;

    // --------------------------------------------------
    // METHODS
    // --------------------------------------------------

    // Essential Methods:

    public void START(Transform Parent, Vector3 WorldPosition, Vector2 GridPosition)
    {
        gameObject.SetActive(false);
        bombContainer.SetActive(false);

        _init_slice_colliders();
        _init_particle_objects();
        _init_listeners();
        _init_tile_sprites(TileSprite.regular);

        transform.parent = Parent;
        transform.position = WorldPosition;

        isAlive = true;
        isBombPlanted = false;
        worldPosition = transform.position;
        gridPosition = GridPosition;

        void _init_slice_colliders()
        {
            colliderSliceControllers = new ColliderSliceController[6];

            colliderSliceControllers[0] = sliceColliderUp;
            colliderSliceControllers[1] = sliceColliderUpRight;
            colliderSliceControllers[2] = sliceColliderDownRight;
            colliderSliceControllers[3] = sliceColliderDown;
            colliderSliceControllers[4] = sliceColliderDownLeft;
            colliderSliceControllers[5] = sliceColliderUpLeft;
        }

        void _init_particle_objects()
        {
            particleObjects = new GameObject[3];

            particleObjects[0] = spawnParticleEffect;
            particleObjects[1] = crushParticleEffect;
            particleObjects[2] = explosionParticleEffect;
        }

        void _init_listeners()
        {
            for (int i = 0; i < colliderSliceControllers.Length; i++)
            {
                colliderSliceControllers[i].SLICE_TRIGGER_EVENT.AddListener(OnTileClicked);
            }
        }

        void _init_tile_sprites(TileSprite _state)
        {
            switch (_state)
            {
                case TileSprite.regular:
                    tileSpriteContainer.GetComponent<SpriteRenderer>().sprite = regularTileSprite;
                    break;
                case TileSprite.crack_1:
                    tileSpriteContainer.GetComponent<SpriteRenderer>().sprite = crackedTileSprite1;
                    break;
                case TileSprite.crack_2:
                    tileSpriteContainer.GetComponent<SpriteRenderer>().sprite = crackedTileSprite2;
                    break;
            }
        }
    }

    public void SET_DEPTH(bool front)
    {
        if (front)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -1.1f);
        }
        else
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -1);
        }
    }

    public void PLANT_A_BOMB(int Countdown)
    {
        bombContainer.SetActive(true);
        isBombPlanted = true;
        bombCountdown = Countdown + 1;
        bombCountdownText.text = "";

        GUIController.MESSAGE = "Be Careful!";
    }

    public void DECREASE_BOMB_COUNTDOWN(StressReceiver stressReceiver = null)
    {
        if (!isAlive)
        {
            return;
        }

        bombCountdown--;

        DeactivateAllParticleObjects();

        if (bombCountdown == 1)
        {
            GUIController.MESSAGE = "Oh! Not Good!";
        }

        if (bombCountdown <= 0)
        {
            bombCountdownText.text = "";

            explosionParticleEffect.SetActive(true);

            stressReceiver.enabled = true;
            stressReceiver.InduceStress(0.5f);

            print("BOOOM!");

            AudioController.PLAY("Explosion");

            GUIController.GAME_OVER();
        }
        else
        {
            bombCountdownText.text = bombCountdown.ToString();

            Invoke("BlowBombEffect", BoardCreator.BOMB_BLOW_DELAY);
        }   
    }

    public void CLOUD_EFFECT()
    {
        DeactivateAllParticleObjects();

        gameObject.SetActive(true);
        spawnParticleEffect.SetActive(true);
    }

    public void CRUSH_EFFECT()
    {
        isAlive = false;

        if (isBombPlanted)
        {
            GUIController.MESSAGE = "Deactivated!";

            AudioController.PLAY("BombDeactivated");
        }

        StartCoroutine(ApplyingCrushEffect());
    }

    // Transformation Methods:

    public void SET_SCALE(Vector2 scale)
    {
        float _radius_multiplier = (scale.x + scale.y) * 0.5f;

        transform.localScale = new Vector3(scale.x, scale.y);

        _set_crush_particle_effect_scale();

        void _set_crush_particle_effect_scale()
        {
            crushParticleEffect.transform.GetChild(2).transform.localScale = new Vector3(_radius_multiplier, _radius_multiplier, _radius_multiplier);
            crushParticleEffect.transform.GetChild(3).transform.localScale = new Vector3(_radius_multiplier, _radius_multiplier, _radius_multiplier);
        }
    }

    public void SET_LOCATION(Vector3 position)
    {
        transform.position = position;

        worldPosition = transform.position;
    }

    public void SET_ROTATION(float rotation)
    {
        transform.SetPositionAndRotation(transform.position, Quaternion.Euler(new Vector3(0, 0, rotation)));
    }

    public void ROTATE(Vector3 pivotPoint, float rotationSpeed)
    {
        transform.RotateAround(pivotPoint, new Vector3(0, 0, 1), rotationSpeed);
    }

    // Access Methods:

    public bool IS_ALIVE
    {
        get
        {
            return isAlive;
        }
    }

    public Vector2 BOUND_SIZE
    {
        get 
        {
            boundSize = tileSpriteContainer.GetComponent<SpriteRenderer>().bounds.size;

            return boundSize; 
        }
    }

    public Color COLOR
    {
        get
        {
            color = tileSpriteContainer.GetComponent<SpriteRenderer>().color;

            return color;
        }
        set
        {
            color = value;

            tileSpriteContainer.GetComponent<SpriteRenderer>().color = color;

            SetColorCrushParticleEffect();
        }  
    }

    public Vector2 GRID_POSITION
    {
        get
        {
            return gridPosition;
        }
        set
        {
            gridPosition = value;
        }
    }

    public Vector3 WORLD_POSITISON
    {
        get
        {
            return worldPosition;
        }
        set
        {
            worldPosition = value;

            transform.position = worldPosition;
        }
    }

    // --------------------------------------------------
    // ACTIONS
    // --------------------------------------------------

    private void OnTileClicked(SliceColliderDirection _slice_collider_direction)
    {
        BoardController.ROTATE_TRIANGLE(this, _slice_collider_direction);
    }

    // --------------------------------------------------
    // FUNCTIONS
    // --------------------------------------------------

    private void SetColorCrushParticleEffect()
    {
        var _crush_effect_big_rocks_main = crushParticleEffect.transform.GetChild(2).GetComponent<ParticleSystem>().main;
        var _crush_effect_small_rocks_main = crushParticleEffect.transform.GetChild(2).GetComponent<ParticleSystem>().main;

        _crush_effect_big_rocks_main.startColor = new Color(color.r, color.g, color.b, 0.5f);
        _crush_effect_small_rocks_main.startColor = new Color(color.r, color.g, color.b, 0.5f);
    }        

    private void DeactivateAllParticleObjects()
    {
        for (int i = 0; i < particleObjects.Length; i++)
        {
            particleObjects[i].SetActive(false);
        }
    }

    // --------------------------------------------------
    // COROUTINES
    // --------------------------------------------------

    private IEnumerator ApplyingCrushEffect()
    {
        bombContainer.SetActive(false);
        tileSpriteContainer.transform.localRotation = Quaternion.Euler(0, 0, 60 * Random.Range(0, 5));
        tileSpriteContainer.GetComponent<SpriteRenderer>().sprite = crackedTileSprite1;

        yield return new WaitForSeconds(BoardCreator.PROGRESS_DELAY);

        tileSpriteContainer.GetComponent<SpriteRenderer>().sprite = crackedTileSprite2;

        yield return new WaitForSeconds(BoardCreator.PROGRESS_DELAY);

        tileSpriteContainer.SetActive(false);
        crushParticleEffect.SetActive(true);

        yield break;
    }

    private void BlowBombEffect()
    {
        CancelInvoke();

        if (GUIController.STATE == GUIState.Game)
        {
            spawnParticleEffect.SetActive(true);

            AudioController.PLAY("Blow");
        }
    }
}
