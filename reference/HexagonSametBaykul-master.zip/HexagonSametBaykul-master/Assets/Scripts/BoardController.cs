﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// --------------------------------------------------
// ENUMERATIONS
// --------------------------------------------------

public enum BoardControllerState
{
    Idle, Rotation, Matching, Gravity, Shifting, Creating,
    RotationComplete, MatchingComplete, GravityComplete, ShiftingComplete, CreatingComplete
};

// --------------------------------------------------
// BoardController.cs
// --------------------------------------------------

public class BoardController : MonoBehaviour
{
    // --------------------------------------------------
    // EDITOR VARIABLES
    // --------------------------------------------------

    [Header("General Rules")]
    public int triangularRotationCountLimit = 3;
    public int scorePerTile = 5;
    public bool shuffleAtNoMoveLeft = true;
    public bool noMatchNoBombCount = true;

    [Header("Bomb Rules")]
    public StressReceiver stressReceiver;
    public bool isThereBomb = true;
    public int bombCountdown = 5;
    public int firstBombActivationPoint = 250;
    public int bombPointInterval = 100;

    [Header("Editor Support")]
    public bool printStates = false;
    public bool printMatchInfo = false;

    // --------------------------------------------------
    // PRIVATE VARIABLES
    // --------------------------------------------------

    private static BoardController staticInstance;
    private static BoardControllerState state;
    private static int matchesPerMove;
    private static bool isTilesTouchable;
    private static bool isMatchFoundOnRotating;

    // Bomb:
    private static List<TileController> bombedTiles;
    private static int nextBombActivationPoint;

    // --------------------------------------------------
    // FUNDAMENTAL
    // --------------------------------------------------

    private void Awake()
    {
        staticInstance = GetComponent<BoardController>();
    }

    // --------------------------------------------------
    // METHODS
    // --------------------------------------------------

    public static void INIT()
    {
        isTilesTouchable = true;
        isMatchFoundOnRotating = false;

        _init_bomb_parameters();

        GUIController.MESSAGE = "Start!";

        void _init_bomb_parameters()
        {
            bombedTiles = new List<TileController>();
            nextBombActivationPoint = staticInstance.firstBombActivationPoint;

            staticInstance.stressReceiver.enabled = false;
        }
    }

    public static void ROTATE_TRIANGLE(TileController starterTile, SliceColliderDirection sliceColliderDirection)
    {
        if (!TOUCHABLE)
        {
            return;
        }

        TileController[] tiles_in_triangle = new TileController[3];

        if (_check_is_triangle())
        {
            matchesPerMove = 0;

            TOUCHABLE = false;

            GUIController.IS_RESTART_BUTTON_ACTIVE = false;

            staticInstance.StartCoroutine(staticInstance.RotatingTilesInTriangle(tiles_in_triangle, _get_triangle_center(tiles_in_triangle)));
        }
        else
        {
            AudioController.PLAY("Wrong");
        }

        bool _check_is_triangle()
        {
            switch (sliceColliderDirection)
            {
                case SliceColliderDirection.up:
                    return _get_triangle(BoardCreator.GET_ADJACENT_TILES(starterTile, true, Direction.UpLeft, Direction.UpRight));
                    break;

                case SliceColliderDirection.upRight:
                    return _get_triangle(BoardCreator.GET_ADJACENT_TILES(starterTile, true, Direction.UpRight, Direction.Right));
                    break;

                case SliceColliderDirection.downRight:
                    return _get_triangle(BoardCreator.GET_ADJACENT_TILES(starterTile, true, Direction.Right, Direction.DownRight));
                    break;

                case SliceColliderDirection.down:
                    return _get_triangle(BoardCreator.GET_ADJACENT_TILES(starterTile, true, Direction.DownRight, Direction.DownLeft));
                    break;

                case SliceColliderDirection.downLeft:
                    return _get_triangle(BoardCreator.GET_ADJACENT_TILES(starterTile, true, Direction.DownLeft, Direction.Left));
                    break;

                case SliceColliderDirection.upLeft:
                    return _get_triangle(BoardCreator.GET_ADJACENT_TILES(starterTile, true, Direction.Left, Direction.UpLeft));
                    break;

                default:
                    return false;
                    break;
            }
        }

        Vector3 _get_triangle_center(TileController[] _tiles_in_triangle)
        {
            Vector3 _triangle_center_point = new Vector3(0, 0, 0);

            for (int i = 0; i < _tiles_in_triangle.Length; i++)
            {
                _triangle_center_point.x += _tiles_in_triangle[i].transform.position.x;
                _triangle_center_point.y += _tiles_in_triangle[i].transform.position.y;
            }

            _triangle_center_point.x /= 3;
            _triangle_center_point.y /= 3;

            return _triangle_center_point;
        }

        bool _get_triangle(TileController[] _tiles_in_triangle_found)
        {
            if (_tiles_in_triangle_found[1] != null && _tiles_in_triangle_found[2] != null)
            {
                tiles_in_triangle = _tiles_in_triangle_found;

                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public static List<Triangle> FIND_POSSIBLE_MATCH_MOVES()
    {
        List<Triangle> _triangles = BoardCreator.FIND_TRIANGLES();
        List<Triangle> _possible_triangles_for_match = new List<Triangle>();

        for (int i = 0; i < _triangles.Count; i++)
        {
            if (_check_triangle(_triangles[i]))
            {
                _possible_triangles_for_match.Add(_triangles[i]);
            }
        }

        if (_triangles.Count > 0)
        {
            if (staticInstance.printMatchInfo)
            {
                print("Match Moves: " + _possible_triangles_for_match.Count + " | Possible Moves: " + _triangles.Count + " | Chance: " + _possible_triangles_for_match.Count * 100 / _triangles.Count + "%.");
            }

            GUIController.TOTAL_MOVE = _triangles.Count;
            GUIController.POSSIBLE_MATCH = _possible_triangles_for_match.Count;
        }

        return _possible_triangles_for_match;

        bool _check_triangle(Triangle _triangle)
        {
            List<Color> _colors_in_center;
            List<Color> _colors_in_relative;

            if (_triangle.hasBinaryColor)
            {
                _colors_in_center = _update_colors_in_center(_triangle, true);
                _colors_in_relative = _update_colors_in_relatives(_triangle, true);

                if(_check_colors(_colors_in_center, _colors_in_relative))
                {
                    return true;
                }
            }

            _colors_in_center = _update_colors_in_center(_triangle, false);
            _colors_in_relative = _update_colors_in_relatives(_triangle, false);

            return _check_colors(_colors_in_center, _colors_in_relative);
        }

        bool _check_colors(List<Color> _color_group_a, List<Color> _color_group_b)
        {
            for (int i = 0; i < _color_group_a.Count; i++)
            {
                for (int j = 0; j < _color_group_b.Count; j++)
                {
                    if (_color_group_a[i] == _color_group_b[j])
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        List<Color> _update_colors_in_center(Triangle _triangle, bool _has_binary_colors)
        {
            List<Color> _colors_in_center_found = new List<Color>();

            if (_has_binary_colors)
            {
                _colors_in_center_found.Add(_triangle.binaryColorIfHas);
            }
            else
            {
                _colors_in_center_found.Add(_triangle.centerTile.COLOR);
                _colors_in_center_found.Add(_triangle.leftTile.COLOR);
                _colors_in_center_found.Add(_triangle.rightTile.COLOR);
            }

            return _colors_in_center_found;
        }

        List<Color> _update_colors_in_relatives(Triangle _triangle, bool _has_binary_colors)
        {
            List<Color> _colors_in_relatives_found = new List<Color>();
            TileController[] _tiles_in_relatives;

            if (_has_binary_colors)
            {
                _tiles_in_relatives = _find_intermediate_tiles_in_relatives(_triangle);

                for (int i = 0; i < _tiles_in_relatives.Length; i++)
                {
                    if (_tiles_in_relatives[i] != null)
                    {
                        _colors_in_relatives_found.Add(_tiles_in_relatives[i].COLOR);
                    }
                }
            }
            else
            {
                _tiles_in_relatives = _find_all_tiles_in_relatives(_triangle);

                for (int i = 0; i < _tiles_in_relatives.Length; i++)
                {
                    if (i == 0)
                    {
                        if (_tiles_in_relatives[0] != null && _tiles_in_relatives[_tiles_in_relatives.Length - 1] != null)
                        {
                            if (_tiles_in_relatives[0].COLOR == _tiles_in_relatives[_tiles_in_relatives.Length - 1].COLOR)
                            {
                                _colors_in_relatives_found.Add(_tiles_in_relatives[0].COLOR);
                            }
                        }
                    }
                    else
                    {
                        if (_tiles_in_relatives[i] != null && _tiles_in_relatives[i - 1] != null)
                        {
                            if (_tiles_in_relatives[i].COLOR == _tiles_in_relatives[i - 1].COLOR)
                            {
                                _colors_in_relatives_found.Add(_tiles_in_relatives[i].COLOR);
                            }
                        }
                    }
                }
            }

            return _colors_in_relatives_found;
        }

        TileController[] _find_intermediate_tiles_in_relatives(Triangle _triangle)
        {
            TileController[] _tiles_in_relatives_found = new TileController[3];

            if (_triangle.isVshape)
            {
                _tiles_in_relatives_found[0] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.Right);
                _tiles_in_relatives_found[1] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.Left);
                _tiles_in_relatives_found[2] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.UpRight);
            }
            else
            {
                _tiles_in_relatives_found[0] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.UpRight);
                _tiles_in_relatives_found[1] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.DownLeft);
                _tiles_in_relatives_found[2] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.UpLeft);
            }

            return _tiles_in_relatives_found;
        }

        TileController[] _find_all_tiles_in_relatives(Triangle _triangle)
        {
            TileController[] _tiles_in_relatives_found = new TileController[9];

            if (_triangle.isVshape)
            {
                _tiles_in_relatives_found[0] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.DownRight);
                _tiles_in_relatives_found[1] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.DownLeft);
                _tiles_in_relatives_found[2] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.Left);
                _tiles_in_relatives_found[3] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.Left);
                _tiles_in_relatives_found[4] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.UpLeft);
                _tiles_in_relatives_found[5] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.UpRight);
                _tiles_in_relatives_found[6] = BoardCreator.GET_ADJACENT_TILE(_triangle.rightTile, Direction.UpRight);
                _tiles_in_relatives_found[7] = BoardCreator.GET_ADJACENT_TILE(_triangle.rightTile, Direction.Right);
                _tiles_in_relatives_found[8] = BoardCreator.GET_ADJACENT_TILE(_triangle.rightTile, Direction.DownRight);
            }
            else
            {
                _tiles_in_relatives_found[0] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.UpRight);
                _tiles_in_relatives_found[1] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.Right);
                _tiles_in_relatives_found[2] = BoardCreator.GET_ADJACENT_TILE(_triangle.centerTile, Direction.DownRight);
                _tiles_in_relatives_found[3] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.DownRight);
                _tiles_in_relatives_found[4] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.DownLeft);
                _tiles_in_relatives_found[5] = BoardCreator.GET_ADJACENT_TILE(_triangle.leftTile, Direction.Left);
                _tiles_in_relatives_found[6] = BoardCreator.GET_ADJACENT_TILE(_triangle.rightTile, Direction.Left);
                _tiles_in_relatives_found[7] = BoardCreator.GET_ADJACENT_TILE(_triangle.rightTile, Direction.UpLeft);
                _tiles_in_relatives_found[8] = BoardCreator.GET_ADJACENT_TILE(_triangle.rightTile, Direction.UpRight);
            }

            return _tiles_in_relatives_found;
        }
    }

    // Access Methods:

    public static bool TOUCHABLE
    {
        get
        {
            return isTilesTouchable;
        }
        set
        {
            isTilesTouchable = value;
        }
    }

    public static BoardControllerState STATE
    {
        set
        {
            state = value;

            if (staticInstance.printStates)
            {
                print("BoardController.STATE = " + state);
            }
        }
        get
        {
            return state;
        }
    }

    // --------------------------------------------------
    // FUNCTIONS
    // --------------------------------------------------

    private List<TileController> GetMatchedTiles()
    {
        List<TileController> _matched_tiles = new List<TileController>();

        for (int x = 0; x < BoardCreator.TILE_GRID.GetLength(0); x++)
        {
            for (int y = 0; y < BoardCreator.TILE_GRID.GetLength(1); y++)
            {
                _check_tile_colors(BoardCreator.GET_ADJACENT_TILES(BoardCreator.TILE_GRID[x, y], true, Direction.UpRight, Direction.Right));
                _check_tile_colors(BoardCreator.GET_ADJACENT_TILES(BoardCreator.TILE_GRID[x, y], true, Direction.Right, Direction.DownRight));
                _check_tile_colors(BoardCreator.GET_ADJACENT_TILES(BoardCreator.TILE_GRID[x, y], true, Direction.DownRight, Direction.DownLeft));
                _check_tile_colors(BoardCreator.GET_ADJACENT_TILES(BoardCreator.TILE_GRID[x, y], true, Direction.DownLeft, Direction.Left));
                _check_tile_colors(BoardCreator.GET_ADJACENT_TILES(BoardCreator.TILE_GRID[x, y], true, Direction.Left, Direction.UpLeft));
                _check_tile_colors(BoardCreator.GET_ADJACENT_TILES(BoardCreator.TILE_GRID[x, y], true, Direction.UpLeft, Direction.UpRight));
            }
        }

        return _matched_tiles;

        void _check_tile_colors(TileController[] _tiles)
        {
            if (_tiles[1] != null && _tiles[2] != null)
            {
                if (_tiles[0].COLOR == _tiles[1].COLOR && _tiles[0].COLOR == _tiles[2].COLOR)
                {
                    if (!_matched_tiles.Contains(_tiles[0]))
                    {
                        _matched_tiles.Add(_tiles[0]);
                    }

                    if (!_matched_tiles.Contains(_tiles[1]))
                    {
                        _matched_tiles.Add(_tiles[1]);
                    }

                    if (!_matched_tiles.Contains(_tiles[2]))
                    {
                        _matched_tiles.Add(_tiles[2]);
                    }
                }
            }
        }
    }

    private void GetPointsFromMatchedTiles(int _number_of_matched_tiles)
    {
        matchesPerMove += _number_of_matched_tiles;

        GUIController.SCORE += scorePerTile * _number_of_matched_tiles;
    }

    private void FinishMove()
    {
        int _possible_match_moves = FIND_POSSIBLE_MATCH_MOVES().Count;

        TOUCHABLE = true;

        GUIController.IS_RESTART_BUTTON_ACTIVE = true;

        _check_move_left();
        _update_bombs();
        _update_message();

        STATE = BoardControllerState.Idle;

        void _check_move_left()
        {
            if (_possible_match_moves == 0)
            {
                if (shuffleAtNoMoveLeft)
                {
                    BoardCreator.RESTART_BOARD();
                }
                else
                {
                    GUIController.MESSAGE = "No move left!";

                    GUIController.GAME_OVER();
                }
            }
        }

        void _update_bombs()
        {
            if (!isMatchFoundOnRotating && noMatchNoBombCount)
            {
                return;
            }

            if (bombedTiles.Count > 0)
            {
                for (int i = 0; i < bombedTiles.Count; i++)
                {
                    if (bombedTiles[i] != null)
                    {
                        bombedTiles[i].DECREASE_BOMB_COUNTDOWN(stressReceiver);
                    }
                }

                bombedTiles.RemoveAll(clearedBombedTile => clearedBombedTile == null);
            }
        }

        void _update_message()
        {
            if (matchesPerMove >= 18)
            {
                GUIController.MESSAGE = "Incredible!";
            }
            else if (matchesPerMove >= 12)
            {
                GUIController.MESSAGE = "Superb!";
            }
            else if (matchesPerMove >= 6)
            {
                GUIController.MESSAGE = "Great!";
            }
            else if (matchesPerMove == 0)
            {
                GUIController.MESSAGE = "Ew!";
            }

            if (printMatchInfo)
            {
                print("Matched Tiles: " + matchesPerMove + " | Gained Points: " + scorePerTile * matchesPerMove);
            }
        }
    }

    // --------------------------------------------------
    // COROUTINES
    // --------------------------------------------------

    private IEnumerator RotatingTilesInTriangle(TileController[] _tiles_in_triangle, Vector3 _triangle_center_point)
    {
        int _rotation_angle = 360 / _tiles_in_triangle.Length;

        isMatchFoundOnRotating = false;

        for (int _rotation_count = 0; _rotation_count < triangularRotationCountLimit; _rotation_count++)
        {
            for (int i = 0; i < _tiles_in_triangle.Length; i++)
            {
                bool _last_tile = (i == _tiles_in_triangle.Length - 1);

                if (i == 0)
                {
                    STATE = BoardControllerState.Rotation;
                }

                StartCoroutine(RotatingTileInTriangle(_tiles_in_triangle[i], _triangle_center_point, BoardCreator.ROTATION_SPEED, _rotation_angle, _last_tile));
            }

            AudioController.PLAY("Rotation");

            yield return new WaitUntil(() => STATE == BoardControllerState.RotationComplete);

            _order_tiles_after_rotation();

            yield return new WaitForSeconds(BoardCreator.PROGRESS_DELAY);

            StartCoroutine(CheckingMatches());

            yield return new WaitUntil(() => STATE == BoardControllerState.MatchingComplete);

            if (isMatchFoundOnRotating)
            {
                FinishMove();

                yield break;
            }
        }

        FinishMove();

        yield break;

        void _order_tiles_after_rotation()
        {
            Vector2[] _tile_grid_positions = new Vector2[3];
            Vector3[] _tile_world_positions = new Vector3[3];

            TileController _tile_0 = _tiles_in_triangle[0];
            TileController _tile_1 = _tiles_in_triangle[1];
            TileController _tile_2 = _tiles_in_triangle[2];

            for (int i = 0; i < _tile_grid_positions.Length; i++)
            {
                _tile_grid_positions[i] = _tiles_in_triangle[i].GRID_POSITION;
                _tile_world_positions[i] = _tiles_in_triangle[i].WORLD_POSITISON;
            }

            if (BoardCreator.ROTATION_SPEED > 0)
            {
                _tiles_in_triangle[0] = _tile_2;
                _tiles_in_triangle[1] = _tile_0;
                _tiles_in_triangle[2] = _tile_1;
            }
            else if (BoardCreator.ROTATION_SPEED < 0)
            {
                _tiles_in_triangle[0] = _tile_1;
                _tiles_in_triangle[1] = _tile_2;
                _tiles_in_triangle[2] = _tile_0;
            }

            for (int i = 0; i < _tile_grid_positions.Length; i++)
            {
                _tiles_in_triangle[i].GRID_POSITION = _tile_grid_positions[i];
                _tiles_in_triangle[i].WORLD_POSITISON = _tile_world_positions[i];

                BoardCreator.TILE_GRID[(int)_tile_grid_positions[i].x, (int)_tile_grid_positions[i].y] = _tiles_in_triangle[i];
            }
        }
    }

    private IEnumerator RotatingTileInTriangle(TileController _tile_in_triangle, Vector3 _pivot_point, float _speed, int _angle, bool _last_tile)
    {
        float _init_rotation;
        float _current_rotation;
        int _target_rotation;
        float _actual_rotation_speed;

        _tile_in_triangle.SET_DEPTH(true);

        _init_rotations();

        while (_current_rotation > _target_rotation)
        {
            _actual_rotation_speed = -_speed * Time.deltaTime;

            _tile_in_triangle.ROTATE(_pivot_point, _actual_rotation_speed);

            _current_rotation += _actual_rotation_speed;

            yield return null;
        }

        _tile_in_triangle.SET_ROTATION(_init_rotation);
        _tile_in_triangle.SET_DEPTH(false);

        if (_last_tile)
        {
            STATE = BoardControllerState.RotationComplete;
        }

        yield break;

        void _init_rotations()
        {
            _init_rotation = transform.rotation.eulerAngles.z;
            _current_rotation = _init_rotation;

            if (_current_rotation <= 0)
            {
                _current_rotation += 360;
            }

            _target_rotation = (int)_current_rotation - _angle;

            if (_target_rotation < 0)
            {
                _target_rotation += 360;
            }
        }
    }

    private IEnumerator CheckingMatches()
    {
        List<TileController> _matched_tiles;

        bool isMatchFound = true;

        STATE = BoardControllerState.Matching;

        while (isMatchFound)
        {
            isMatchFound = false;

           _matched_tiles = GetMatchedTiles();

            if (_matched_tiles.Count > 0)
            {
                int _number_of_matched_tiles = _matched_tiles.Count;

                isMatchFound = true;
                isMatchFoundOnRotating = true;

                _destroy_matched_tiles();

                AudioController.PLAY("Crush");

                yield return new WaitForSeconds(BoardCreator.PROGRESS_DELAY * 2);

                GetPointsFromMatchedTiles(_number_of_matched_tiles);

                StartCoroutine(ApplyingGravitationalEffect());

                yield return new WaitUntil(() => STATE == BoardControllerState.GravityComplete);
            }
        }

        STATE = BoardControllerState.MatchingComplete;

        yield break;

        void _destroy_matched_tiles()
        {
            for (int i = 0; i < _matched_tiles.Count; i++)
            {
                BoardCreator.DELETE_TILE(_matched_tiles[i].GRID_POSITION);
            }

            _matched_tiles.Clear();
        }
    }

    private IEnumerator ApplyingGravitationalEffect()
    {
        List<TileController> _tiles_in_shifting = new List<TileController>();
        List<int> _rows_for_new_tiles = new List<int>();

        bool _is_there_any_missing_tile = true;

        STATE = BoardControllerState.Gravity;

        while (_is_there_any_missing_tile)
        {
            _is_there_any_missing_tile = false;

            _find_missing_tiles();
            _shift_tiles();

            if (STATE == BoardControllerState.Shifting)
            {
                yield return new WaitUntil(() => STATE == BoardControllerState.ShiftingComplete);
            }

            if (_is_there_any_missing_tile)
            {
                _find_rows_for_new_tiles();
                _create_new_tiles();

                AudioController.PLAY("TileSpawn");
            }

            if (STATE == BoardControllerState.Creating)
            {
                yield return new WaitUntil(() => STATE == BoardControllerState.CreatingComplete);
            }
        }

        STATE = BoardControllerState.GravityComplete;

        yield break;

        void _find_missing_tiles()
        {
            for (int x = 0; x < BoardCreator.TILE_GRID.GetLength(0); x++)
            {
                for (int y = 0; y < BoardCreator.TILE_GRID.GetLength(1); y++)
                {
                    if (BoardCreator.TILE_GRID[x, y] == null)
                    {
                        _is_there_any_missing_tile = true;

                        for (int i = y; i < BoardCreator.TILE_GRID.GetLength(1); i++)
                        {
                            if (BoardCreator.TILE_GRID[x, i] != null)
                            {
                                _tiles_in_shifting.Add(BoardCreator.TILE_GRID[x, i]);
                            }
                        }
                    }
                }
            }
        }

        void _shift_tiles()
        {
            bool _last_tile;

            for (int i = 0; i < _tiles_in_shifting.Count; i++)
            {
                if (i == 0)
                {
                    STATE = BoardControllerState.Shifting;
                }

                _last_tile = (i == _tiles_in_shifting.Count - 1);

                StartCoroutine(ShiftingTileDown(_tiles_in_shifting[i], _last_tile));
            }

            _tiles_in_shifting.Clear();
        }

        void _find_rows_for_new_tiles()
        {
            for (int x = 0; x < BoardCreator.TILE_GRID.GetLength(0); x++)
            {
                if (BoardCreator.TILE_GRID[x, BoardCreator.TILE_GRID.GetLength(1) - 1] == null)
                {
                    _rows_for_new_tiles.Add(x);
                }
            }
        }

        void _create_new_tiles()
        {
            bool _last_tile;

            for (int i = 0; i < _rows_for_new_tiles.Count; i++)
            {
                if (i == 0)
                {
                    STATE = BoardControllerState.Creating;
                }

                _last_tile = (i == _rows_for_new_tiles.Count - 1);

                StartCoroutine(CreatingTile(_rows_for_new_tiles[i], _last_tile));
            }

            _rows_for_new_tiles.Clear();
        }
    }

    private IEnumerator ShiftingTileDown(TileController _tile_in_shifting, bool _last_tile)
    {
        Vector2 _initial_grid_pos = _tile_in_shifting.GRID_POSITION;
        Vector2 _target_grid_pos = BoardCreator.GET_ADJACENT_TILE_GRID_POSITION(_tile_in_shifting, Direction.Down);
        Vector3 _initial_world_pos = _tile_in_shifting.WORLD_POSITISON;
        Vector3 _target_world_pos = BoardCreator.GET_ADJACENT_TILE_WORLD_POSITION(_tile_in_shifting, Direction.Down);

        float _current_falling_progress = 0;

        _tile_in_shifting.SET_DEPTH(true);

        while (_current_falling_progress < 1)
        {
            _current_falling_progress += BoardCreator.FALLING_SPEED * Time.deltaTime;

            _tile_in_shifting.SET_LOCATION(Vector3.Lerp(_initial_world_pos, _target_world_pos, _current_falling_progress));

            yield return null;
        }

        _tile_in_shifting.SET_LOCATION(_target_world_pos);
        _tile_in_shifting.GRID_POSITION = _target_grid_pos;
        _tile_in_shifting.SET_DEPTH(false);

        BoardCreator.TILE_GRID[(int)_initial_grid_pos.x, (int)_initial_grid_pos.y] = null;
        BoardCreator.TILE_GRID[(int)_target_grid_pos.x, (int)_target_grid_pos.y] = _tile_in_shifting;

        if (_last_tile)
        {
            STATE = BoardControllerState.ShiftingComplete;
        }

        yield break;
    }

    private IEnumerator CreatingTile(int _x, bool _last_tile)
    {
        TileController _new_tile = BoardCreator.CREATE_TILE(_x, BoardCreator.TILE_GRID.GetLength(1) - 1);

        _try_plant_a_bomb();

        yield return new WaitForSeconds(BoardCreator.PROGRESS_DELAY);

        if (_last_tile)
        {
            STATE = BoardControllerState.CreatingComplete;
        }

        yield break;

        void _try_plant_a_bomb()
        {
            if (isThereBomb && bombCountdown > 0)
            {
                if (GUIController.SCORE >= nextBombActivationPoint)
                {
                    _new_tile.PLANT_A_BOMB(bombCountdown);

                    bombedTiles.Add(_new_tile);
                    nextBombActivationPoint += bombPointInterval;

                    AudioController.PLAY("BombSpawn");
                }
            }
        }
    }
}
